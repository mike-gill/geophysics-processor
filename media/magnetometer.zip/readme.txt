EPE PIC Magnetometer by John Becker

Everyday Practical Electronics, July/ August 2004

Based on the high sensitivity FGM-3 fluxgate sensor, this project
is designed to measure the direction and/ or intensity of the earth's
magnetic fields, in order to help locate any disturbances underneath.
Helps pinpoint hidden artifacts and other archaeological features.

PC serial interface and optional GPS interface. Data logging feature.
Valuable free Windows software.

Free source code available for download from 
http://www.epemag.wimborne.co.uk/downloads.html

Parts are available from the usual component sources. Please note
that EPE does not provide kits but many of the requirements can
be met by our advertisers.

Please refer to the EPE web site for details of ordering back issues,
subscriptions etc.

http://www.epemag.wimborne.co.uk

Last updated 11th June 2004